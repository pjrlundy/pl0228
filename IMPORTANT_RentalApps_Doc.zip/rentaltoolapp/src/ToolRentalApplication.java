import java.time.LocalDate;

public class ToolRentalApplication {

    public static void main(String[] args) {
        // Initialize some tools
        Tool ladder = new Tool("LADW", "Ladder", "Werner");
        Tool chainsaw = new Tool("CHNS", "Chainsaw", "Stihl");
        Tool jackhammerDewalt = new Tool("JAKD", "Jackhammer", "DeWalt");
        Tool jackhammerRidgid = new Tool("JAKR", "Jackhammer", "Ridgid");

        // Simulate checkouts
        try {
            RentalAgreement rental1 = new RentalAgreement(ladder, 5, 10, LocalDate.of(2024, 3, 15));
            rental1.printAgreement();

            RentalAgreement rental2 = new RentalAgreement(chainsaw, 3, 25, LocalDate.of(2024, 7, 2));
            rental2.printAgreement();

            RentalAgreement rental3 = new RentalAgreement(jackhammerDewalt, 6, 0, LocalDate.of(2024, 9, 3));
            rental3.printAgreement();

            RentalAgreement rental4 = new RentalAgreement(jackhammerRidgid, 9, 50, LocalDate.of(2024, 12, 24));
            rental4.printAgreement();
        } catch (IllegalArgumentException e) {
            System.out.println("Error during checkout: " + e.getMessage());
        }
    }
}
