
Please find three versions of the Rental Application:

rentaltoolapp          => This version showcases a solid grasp of Java modular and Object-Oriented Programming principles.
rentaltoolappenhance   => This implementation utilizes more advanced concepts like interfaces, dependency injection, and factory design patterns.
rentaltoolspring       => This version takes advantage of Spring Boot for its framework.