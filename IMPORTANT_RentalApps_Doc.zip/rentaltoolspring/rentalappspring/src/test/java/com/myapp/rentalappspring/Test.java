package com.myapp.rentalappspring;

public @interface Test {

}
