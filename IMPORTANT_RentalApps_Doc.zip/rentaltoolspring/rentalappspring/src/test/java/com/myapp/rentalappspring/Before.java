package com.myapp.rentalappspring;

public @interface Before {

}
