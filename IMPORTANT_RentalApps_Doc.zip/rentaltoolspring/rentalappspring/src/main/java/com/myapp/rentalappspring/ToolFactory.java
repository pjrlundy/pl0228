package com.myapp.rentalappspring;

import org.springframework.stereotype.Service;

@Service
public class ToolFactory {

    
    public Tool createTool(String code, String type, String brand) {
        return new Tool(code, type, brand);
    }
}



