package com.myapp.rentalappspring;

public class ApplicationConfig {
    
}
